import { useState } from 'react';
import { Tv, Film, MonitorPlay, Globe, Shield, X, Download, Users, CheckCircle, Smartphone } from 'lucide-react';
import { translations, Language } from './i18n';

export default function App() {
  const [lang, setLang] = useState<Language>('en');
  const [showSignIn, setShowSignIn] = useState(false);

  const t = translations[lang];

  return (
    <div className="min-h-screen bg-[#050505] text-white font-sans overflow-x-hidden flex flex-col p-4 md:p-6 lg:p-8 gap-6 max-w-[1280px] mx-auto">
      
      {/* Background Gradient */}
      <div className="fixed top-0 left-0 w-full h-[80vh] pointer-events-none z-0" style={{
        background: 'radial-gradient(120% 100% at 50% 0%, rgba(138, 10, 15, 0.45) 0%, rgba(5, 5, 5, 1) 100%)'
      }} />

      {/* Header Navigation */}
      <nav className="relative z-50 flex justify-between items-center px-4 shrink-0">
        <div className="flex items-center gap-8">
          <span className="text-4xl font-black tracking-tighter text-red-600">NERO</span>
          <div className="hidden lg:flex gap-6 text-sm font-medium opacity-60">
            <a href="#pricing" className="hover:opacity-100">{t.nav.pricing}</a>
            <a href="#features" className="hover:opacity-100">{t.nav.features}</a>
            <a href="#download" className="hover:opacity-100">{t.nav.download}</a>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <button className="hidden sm:flex bg-red-600/10 text-red-500 px-4 py-2 text-xs md:text-sm rounded-lg font-bold border border-red-500/20 hover:bg-red-600 hover:text-white transition-all items-center gap-2 whitespace-nowrap">
            <MonitorPlay size={16} /> {t.nav.webVersion}
          </button>
          <div className="flex bg-[#1a1a1a] p-1 rounded-full border border-white/10 hidden sm:flex">
            <button 
              onClick={() => setLang('en')}
              className={`px-3 md:px-4 py-1.5 text-xs font-bold rounded-full ${lang === 'en' ? 'bg-white text-black' : 'text-white/50 hover:text-white transition-colors'}`}
            >
              EN
            </button>
            <button 
              onClick={() => setLang('sq')}
              className={`px-3 md:px-4 py-1.5 text-xs font-bold rounded-full ${lang === 'sq' ? 'bg-white text-black' : 'text-white/50 hover:text-white transition-colors'}`}
            >
              AL
            </button>
          </div>
          <button 
            onClick={() => setShowSignIn(true)}
            className="bg-red-600 px-4 md:px-6 py-2 rounded-lg text-xs md:text-sm font-bold shadow-lg shadow-red-900/20 hover:bg-red-500 transition-colors whitespace-nowrap"
          >
            {t.nav.signIn}
          </button>
        </div>
      </nav>

      {/* Bento Grid Main Layout */}
      <div className="relative z-10 grid grid-cols-1 md:grid-cols-12 flex-1 gap-4 lg:grid-rows-[repeat(8,minmax(0,1fr))]">
        
        {/* Main Hero Feature */}
        <div className="md:col-span-12 lg:col-span-12 md:row-span-4 rounded-3xl bg-gradient-to-t from-black via-black/40 to-transparent relative overflow-hidden group border border-white/5 min-h-[400px] flex items-end">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=1200')] bg-cover bg-center -z-10 opacity-70 group-hover:scale-105 transition-transform duration-700"></div>
          <div className="absolute inset-x-0 bottom-0 py-48 bg-gradient-to-t from-black via-black/80 to-transparent"></div>
          <div className="relative p-6 md:p-10 w-full z-10">
            <span className="px-3 py-1 bg-red-600/20 text-red-500 text-xs font-bold rounded-md uppercase tracking-widest mb-4 inline-block border border-red-500/30 backdrop-blur-md">
              {t.hero.badge}
            </span>
            <h1 className="text-5xl md:text-7xl font-black mb-4 leading-[0.9]">
              {t.hero.title1}<br />
              <span className="text-red-600">{t.hero.title2}</span>
            </h1>
            <p className="text-lg text-white/60 max-w-lg mb-8 leading-relaxed">
              {t.hero.subtitle}
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                className="bg-white text-black px-8 py-4 rounded-xl font-bold flex items-center justify-center gap-3 hover:bg-white/90 transition-colors"
              >
                <Download className="w-5 h-5 stroke-[2.5]" /> {t.hero.downloadApp}
              </button>
              <button 
                className="bg-[#111]/80 backdrop-blur-md border border-white/10 text-white px-8 py-4 rounded-xl font-bold flex items-center justify-center gap-3 hover:bg-white/10 transition-colors"
              >
                <MonitorPlay className="w-5 h-5 stroke-[2.5]" /> {t.hero.webApp}
              </button>
            </div>
          </div>
        </div>

        {/* Pricing Section Title */}
        <div id="pricing" className="md:col-span-12 lg:col-span-12 md:row-span-1 flex items-end pb-2 pt-6">
          <h2 className="text-2xl md:text-3xl font-black uppercase tracking-widest">{t.planSectionTitle}</h2>
        </div>

        {/* Monthly Pricing Card */}
        <div className="md:col-span-4 lg:col-span-4 md:row-span-2 rounded-3xl bg-gradient-to-br from-zinc-900 to-black p-6 border border-white/10 flex flex-col justify-between relative overflow-hidden group min-h-[220px]">
          <div className="absolute top-0 right-[-10px] p-4 opacity-5 group-hover:opacity-10 transition-opacity">
            <Shield size={100} />
          </div>
          <div className="relative z-10">
            <div className="flex justify-between items-start mb-2">
              <span className="text-xs font-bold uppercase tracking-widest text-red-500 block">{t.pricing.title}</span>
            </div>
            <div className="flex flex-col mb-4">
              <span className="text-sm text-transparent font-bold select-none">&nbsp;</span>
              <div className="flex items-end gap-1">
                <span className="text-4xl font-black">{t.pricing.price}</span>
                <span className="text-sm text-white/40 mb-1 font-bold">{t.pricing.period}</span>
              </div>
            </div>
            <div className="space-y-2 mb-6">
              {t.pricing.features.map((feature, i) => (
                <div key={i} className="flex items-center gap-2 text-xs font-medium text-white/70">
                  <CheckCircle size={14} className="text-red-500 shrink-0" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>
          <button className="w-full bg-white text-black py-3.5 rounded-xl font-bold text-sm hover:bg-white/90 transition-colors relative z-10">
            {t.pricing.subscribe}
          </button>
        </div>

        {/* 6 Months Pricing Card */}
        <div className="md:col-span-4 lg:col-span-4 md:row-span-2 rounded-3xl bg-gradient-to-br from-red-900/40 to-black p-6 border border-red-500/30 flex flex-col justify-between relative overflow-hidden group min-h-[220px]">
          <div className="absolute top-0 right-0 w-32 h-32 bg-red-600/10 rounded-full blur-3xl group-hover:bg-red-600/20 transition-colors"></div>
          <div className="relative z-10">
            <div className="flex justify-between items-start mb-2">
              <span className="text-xs font-bold uppercase tracking-widest text-red-500 block">{t.pricing6.title}</span>
              <span className="text-[10px] font-bold uppercase tracking-widest bg-red-600 text-white px-2 py-0.5 rounded-full">{t.pricing6.badge}</span>
            </div>
            <div className="flex flex-col mb-4">
              <span className="text-sm text-white/40 line-through font-bold">€29.94</span>
              <div className="flex items-end gap-1">
                <span className="text-4xl font-black">{t.pricing6.price}</span>
                <span className="text-sm text-white/40 mb-1 font-bold">{t.pricing6.period}</span>
              </div>
            </div>
            <div className="space-y-2 mb-6">
              {t.pricing.features.map((feature, i) => (
                <div key={i} className="flex items-center gap-2 text-xs font-medium text-white/70">
                  <CheckCircle size={14} className="text-red-500 shrink-0" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>
          <button className="w-full bg-red-600 text-white py-3.5 rounded-xl font-bold text-sm hover:bg-red-500 transition-colors relative z-10 shadow-lg shadow-red-900/20">
            {t.pricing6.subscribe}
          </button>
        </div>

        {/* Annual Pricing Card */}
        <div className="md:col-span-4 lg:col-span-4 md:row-span-2 rounded-3xl bg-gradient-to-br from-zinc-900 to-black p-6 border border-white/10 flex flex-col justify-between relative overflow-hidden group min-h-[220px]">
          <div className="absolute top-0 right-[-10px] p-4 opacity-5 group-hover:opacity-10 transition-opacity">
            <Shield size={100} />
          </div>
          <div className="relative z-10">
            <div className="flex justify-between items-start mb-2">
               <span className="text-xs font-bold uppercase tracking-widest text-red-500 block">{t.pricing12.title}</span>
               <span className="text-[10px] font-bold uppercase tracking-widest bg-white/10 text-white px-2 py-0.5 rounded-full">{t.pricing12.badge}</span>
            </div>
            <div className="flex flex-col mb-4">
              <span className="text-sm text-white/40 line-through font-bold">€59.88</span>
              <div className="flex items-end gap-1">
                <span className="text-4xl font-black">{t.pricing12.price}</span>
                <span className="text-sm text-white/40 mb-1 font-bold">{t.pricing12.period}</span>
              </div>
            </div>
            <div className="space-y-2 mb-6">
              {t.pricing.features.map((feature, i) => (
                <div key={i} className="flex items-center gap-2 text-xs font-medium text-white/70">
                  <CheckCircle size={14} className="text-red-500 shrink-0" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>
          <button className="w-full bg-white text-black py-3.5 rounded-xl font-bold text-sm hover:bg-white/90 transition-colors relative z-10">
            {t.pricing12.subscribe}
          </button>
        </div>

        {/* Features Section Title */}
        <div id="features" className="md:col-span-12 lg:col-span-12 md:row-span-1 flex items-end pb-2 pt-6 mt-4">
          <h2 className="text-2xl md:text-3xl font-black uppercase tracking-widest">{t.featureSectionTitle}</h2>
        </div>

        {/* Features Row */}
        <div className="md:col-span-12 lg:col-span-12 md:row-span-1 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gradient-to-br from-zinc-900 to-black border border-white/10 rounded-3xl p-6 flex flex-col justify-between relative overflow-hidden group transition-colors hover:border-white/20 min-h-[220px]">
            <div className="absolute top-0 right-[-10px] p-4 opacity-5 group-hover:opacity-10 transition-opacity">
              <Film size={100} />
            </div>
            <div className="bg-black/50 p-3.5 rounded-xl text-white/80 group-hover:text-red-500 group-hover:scale-110 transition-all duration-500 shadow-lg border border-white/5 w-fit relative z-10 mb-6">
              <Film size={24} />
            </div>
            <div className="relative z-10">
              <h4 className="text-lg font-bold mb-1">{t.homeFeatures.movies.title}</h4>
              <p className="text-sm font-medium text-white/50">{t.homeFeatures.movies.desc}</p>
            </div>
          </div>
          <div className="bg-gradient-to-br from-red-900/40 to-black border border-red-500/30 rounded-3xl p-6 flex flex-col justify-between relative overflow-hidden group hover:border-red-500/50 transition-colors min-h-[220px]">
            <div className="absolute top-0 right-0 w-32 h-32 bg-red-600/10 rounded-full blur-3xl group-hover:bg-red-600/20 transition-colors"></div>
            <div className="absolute top-0 right-[-10px] p-4 opacity-5 group-hover:opacity-10 transition-opacity">
              <Tv size={100} />
            </div>
            <div className="bg-red-600 p-3.5 rounded-xl text-white group-hover:scale-110 transition-all duration-500 shadow-lg shadow-red-900/20 w-fit relative z-10 mb-6">
              <Tv size={24} />
            </div>
            <div className="relative z-10">
              <h4 className="text-lg font-bold mb-1">{t.homeFeatures.series.title}</h4>
              <p className="text-sm font-medium text-white/50">{t.homeFeatures.series.desc}</p>
            </div>
          </div>
          <div className="bg-gradient-to-br from-zinc-900 to-black border border-white/10 rounded-3xl p-6 flex flex-col justify-between relative overflow-hidden group transition-colors hover:border-white/20 min-h-[220px]">
            <div className="absolute top-0 right-[-10px] p-4 opacity-5 group-hover:opacity-10 transition-opacity">
              <MonitorPlay size={100} />
            </div>
            <div className="bg-black/50 p-3.5 rounded-xl text-white/80 group-hover:text-red-500 group-hover:scale-110 transition-all duration-500 shadow-lg border border-white/5 w-fit relative z-10 mb-6">
              <MonitorPlay size={24} />
            </div>
            <div className="relative z-10">
              <h4 className="text-lg font-bold mb-1">{t.homeFeatures.live.title}</h4>
              <p className="text-sm font-medium text-white/50">{t.homeFeatures.live.desc}</p>
            </div>
          </div>
        </div>

        {/* Subscription CTA - Full Width at bottom */}
        <div id="download" className="md:col-span-12 lg:col-span-12 md:row-span-2 rounded-3xl bg-[url('https://images.unsplash.com/photo-1616469829581-73993eb86b02?q=80&w=1200&auto=format&fit=crop')] bg-cover bg-center border border-white/10 overflow-hidden relative min-h-[200px] flex">
          <div className="absolute inset-0 bg-gradient-to-r from-black/95 via-black/80 to-black/30"></div>
          <div className="absolute right-0 top-0 h-full w-2/3 bg-gradient-to-l from-red-600/20 to-transparent pointer-events-none"></div>
          <div className="p-8 md:p-10 flex flex-col md:flex-row w-full md:items-center justify-between gap-6 relative z-10">
            <div className="flex-1 w-full max-w-xl">
              <h3 className="text-3xl md:text-4xl font-bold mb-2">{t.cta.title}</h3>
              <p className="text-white/50 text-sm md:text-base font-medium max-w-sm">{t.cta.subtitle}</p>
            </div>
            <div className="flex flex-col sm:flex-row items-center gap-2 w-full md:w-auto shrink-0">
              <input type="email" placeholder="Email address" className="bg-black/50 backdrop-blur-md border border-white/20 px-6 py-4 rounded-xl w-full sm:w-72 focus:outline-none focus:border-red-600 transition-colors font-medium placeholder:text-white/30" />
              <button 
                className="bg-red-600 w-full sm:w-auto px-8 py-4 rounded-xl font-bold text-white hover:bg-red-500 transition-colors whitespace-nowrap flex items-center justify-center gap-2 shadow-lg shadow-black/50"
              >
                {t.cta.download} <Download size={18} />
              </button>
            </div>
          </div>
        </div>

      </div>

      {/* Footer / Legal */}
      <footer className="relative z-10 flex flex-col sm:flex-row justify-between items-center py-2 mt-4 text-[10px] uppercase tracking-widest text-white/30 gap-4 text-center sm:text-left border-t border-white/5 pt-4 shrink-0 font-bold">
        <p>{t.footer.rights}</p>
        <div className="flex gap-4 sm:gap-6 flex-wrap justify-center">
          <a href="#" className="hover:text-white transition-colors">{t.footer.privacy}</a>
          <a href="#" className="hover:text-white transition-colors">{t.footer.terms}</a>
          <a href="#" className="hover:text-white transition-colors">{t.footer.help}</a>
        </div>
      </footer>

      {/* Sign In Modal */}
      {showSignIn && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="bg-[#111] border border-white/10 p-8 rounded-2xl w-full max-w-md relative shadow-2xl shadow-black">
            <button 
              onClick={() => setShowSignIn(false)}
              className="absolute top-4 right-4 text-white/30 hover:text-white transition-colors"
            >
              <X size={20} />
            </button>
            <div className="flex justify-center mb-6">
              <div className="w-12 h-12 flex items-center justify-center rounded-xl bg-gradient-to-br from-zinc-800 to-black border border-white/10 shadow-lg shadow-black/50">
                <span className="text-red-600 font-bold text-3xl tracking-tighter">N</span>
              </div>
            </div>
            <h2 className="text-2xl font-bold mb-2 uppercase text-center tracking-wide">WELCOME BACK</h2>
            <p className="text-white/50 text-sm mb-6 text-center font-medium">Enter your details to sign in</p>
            
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-white/50 mb-1 uppercase tracking-wider">Email Address</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none text-white/30">
                    <Globe size={16} />
                  </div>
                  <input type="email" placeholder="example@email.com" className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg py-3 pl-10 pr-4 text-sm font-medium focus:outline-none focus:border-red-600 transition-colors" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-white/50 mb-1 uppercase tracking-wider">Password</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none text-white/30">
                    <Shield size={16} />
                  </div>
                  <input type="password" placeholder="••••••••" className="w-full bg-[#1a1a1a] border border-white/10 rounded-lg py-3 pl-10 pr-4 text-sm font-medium focus:outline-none focus:border-red-600 transition-colors" />
                </div>
              </div>
              <button 
                onClick={() => setShowSignIn(false)}
                className="w-full py-3 mt-4 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-sm transition-all shadow-lg shadow-red-900/20"
              >
                {t.nav.signIn.toUpperCase()}
              </button>
              <div className="text-center mt-4">
                <button className="text-xs text-white/50 hover:text-white uppercase tracking-wider font-bold transition-colors">
                  Create New Account
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
