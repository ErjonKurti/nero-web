export const translations = {
  en: {
    nav: {
      pricing: "Pricing",
      features: "Features",
      download: "Download",
      signIn: "Sign In",
      webVersion: "Web App",
    },
    hero: {
      badge: "Now Available",
      title1: "Stream Unlimited",
      title2: "TV & Movies",
      subtitle: "Discover an immersive library of titles in stunning quality constraint-free.",
      downloadApp: "Download App",
      webApp: "Launch Web App",
    },
    platforms: {
      title: "Available Everywhere",
      desc: "Watch seamlessly on your TV, smartphone, tablet, and browser.",
    },
    profiles: {
      title: "Family Profiles",
      subtitle: "Create up to 5 profiles for everyone in your home.",
    },
    webLaunch: {
      title: "Watch in Browser",
      subtitle: "No download required. Stream instantly.",
      button: "Launch Web TV",
    },
    featureSectionTitle: "Everything You Need",
    homeFeatures: {
      movies: {
        title: "Unlimited Movies",
        desc: "From Hollywood blockbusters to indie gems, available in great quality.",
      },
      series: {
        title: "Binge-worthy Series",
        desc: "The hottest shows from all around the world, updated regularly.",
      },
      live: {
        title: "Live TV Channels",
        desc: "A wide variety of local and international channels at your fingertips.",
      }
    },
    specs: {
      title: "Visual Excellence",
      subtitle: "Experience movies with ultimate clarity",
    },
    localization: {
      title: "Multiple Audio & Subs",
      subtitle: "Enjoy content in native languages with full synchronization support.",
    },
    planSectionTitle: "Choose Your Plan",
    pricing: {
      title: "Premium Plan",
      price: "€4.99",
      period: "/ month",
      desc: "Get unlimited access to all features and content.",
      features: [
        "Ad-free viewing",
        "Great quality",
        "Fast streaming"
      ],
      subscribe: "Choose Plan"
    },
    pricing6: {
      title: "6 Months Plan",
      price: "€24.99",
      period: "/ 6 mos",
      desc: "Save 17% compared to the monthly plan.",
      subscribe: "Choose Plan",
      badge: "Save 17%"
    },
    pricing12: {
      title: "Annual Plan",
      price: "€39.99",
      period: "/ year",
      desc: "Save 33% compared to the monthly plan.",
      subscribe: "Choose Plan",
      badge: "Save 33%"
    },
    cta: {
      title: "Ready to watch?",
      subtitle: "Download the Nero app today and start streaming.",
      placeholder: "Email address",
      download: "Download Now",
    },
    footer: {
      rights: "© 2026 Nero Streaming Co. All rights reserved.",
      terms: "Terms",
      privacy: "Privacy",
      help: "Help"
    }
  },
  sq: {
    nav: {
      pricing: "Çmimet",
      features: "Veçoritë",
      download: "Shkarkime",
      signIn: "Kyçu",
      webVersion: "Web App",
    },
    hero: {
      badge: "E Disponueshme",
      title1: "Shiko Pa Kufi",
      title2: "Filma & TV",
      subtitle: "Eksploroni bibliotekën e filmave me rezolucion mahnitës.",
      downloadApp: "Shkarko App",
      webApp: "Hap Web App",
    },
    platforms: {
      title: "Kudo me ty",
      desc: "Shiko nga TV, telefoni, tableti ose nga shfletuesi yt.",
    },
    profiles: {
      title: "Profile Familjare",
      subtitle: "Krijoni deri në 5 profile për të gjithë familjen tuaj.",
    },
    webLaunch: {
      title: "Shiko në Shfletues",
      subtitle: "Nuk nevojitet shkarkim. Shiko menjëherë.",
      button: "Hap Web TV",
    },
    featureSectionTitle: "Gjithçka që Ju Duhet",
    homeFeatures: {
      movies: {
        title: "Filma Pa Kufi",
        desc: "Nga filmat më të mëdhenj të Hollywood deri tek ata të pavarur, në cilësi të lartë.",
      },
      series: {
        title: "Seriale Binge",
        desc: "Serialet më të ndjekur nga e gjithë bota, të përditësuar rregullisht.",
      },
      live: {
        title: "Kanale TV Live",
        desc: "Një shumëllojshmëri kanalesh lokale dhe ndërkombëtare në majë të gishtave tuaj.",
      }
    },
    specs: {
      title: "Ekselencë Vizuale",
      subtitle: "Shikoni filmat me qartësi absolute",
    },
    localization: {
      title: "Audio & Titra Shumëgjuhësh",
      subtitle: "Kënaquni me përmbajtje në gjuhën dëshiruar me mbështetje sinkronizimi.",
    },
    planSectionTitle: "Zgjidh Planin Tuaj",
    pricing: {
      title: "Plani Premium",
      price: "€4.99",
      period: "/ muaj",
      desc: "Qasje e pakufizuar në çdo veçori dhe përmbajtje.",
      features: [
        "Shiko pa reklama",
        "Kualitet i Lartë",
        "Transmetim i shpejtë"
      ],
      subscribe: "Zgjidh Planin"
    },
    pricing6: {
      title: "Plani 6 Mujor",
      price: "€24.99",
      period: "/ 6 muaj",
      desc: "Kurseni 17% krahasuar me planin mujor.",
      subscribe: "Zgjidh Planin",
      badge: "Kurse 17%"
    },
    pricing12: {
      title: "Plani Vjetor",
      price: "€39.99",
      period: "/ vit",
      desc: "Kurseni 33% krahasuar me planin mujor.",
      subscribe: "Zgjidh Planin",
      badge: "Kurse 33%"
    },
    cta: {
      title: "Gati për të parë?",
      subtitle: "Shkarkoni aplikacionin sot dhe filloni argëtimin.",
      placeholder: "Adresa email",
      download: "Shkarko Tani",
    },
    footer: {
      rights: "© 2026 Nero Streaming Co. Të gjitha të drejtat.",
      terms: "Kushtet",
      privacy: "Privatësia",
      help: "Ndihmë"
    }
  }
};

export type Language = 'en' | 'sq';
